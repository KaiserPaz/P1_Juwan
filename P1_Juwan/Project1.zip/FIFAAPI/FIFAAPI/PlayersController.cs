﻿using System.Data.SqlClient;
namespace FIFAAPI
{
    public class PlayersController 
    {
        #region Properties
        public string playerId { get; set; }
        public string playerName { get; set; }
        public string playerPosition { get; set; }
        public int playerTeamId { get; set; }
        public string playerImage { get; set; }
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string Country { get; set; }
        #endregion

        #region Player Controls
        public List<PlayersController> GetPlayerByName(string p_playerName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("select Teams.TeamId , Teams.TeamName , Teams.Country , Players.playerId, Players.playerName, Players.playerPosition, Players.playerImage from Teams left join Players on Teams.TeamId = Players.playerTeamId where playerName = @playerName", con);
            cmd.Parameters.AddWithValue("@playerName", p_playerName);
            con.Open();
            List<PlayersController> playerlist = new List<PlayersController>();
            SqlDataReader rd = cmd.ExecuteReader();
            try
            {                
                if (rd.Read())
                {
                    playerlist.Add(new PlayersController()
                    {
                        teamId = Convert.ToInt32(rd[0]),
                        teamName = rd[1].ToString(),
                        Country = rd[2].ToString(),
                        playerId = rd[3].ToString(),
                        playerName = rd[4].ToString(),
                        playerPosition = rd[5].ToString(),
                        playerImage = rd[6].ToString()
                    });
                    return playerlist;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }
        }                        
        
        public List<PlayersController> GetPlayersByPosition(string p_position)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("select Teams.TeamId , Teams.TeamName , Teams.Country , Players.playerId, Players.playerName, Players.playerPosition, Players.playerImage from Teams left join Players on Teams.TeamId = Players.playerTeamId where playerPosition = @playerPosition", con);
            cmd.Parameters.AddWithValue("@playerPosition", p_position);
            con.Open();
            List<PlayersController> PlayerList = new List<PlayersController>();
            SqlDataReader rd = cmd.ExecuteReader();            
            try
            {                
                if (rd.Read())
                {
                    while (rd.Read())
                    {                        
                        PlayerList.Add(new PlayersController()
                        {
                            teamId = Convert.ToInt32(rd[0]),
                            teamName = rd[1].ToString(),
                            Country = rd[2].ToString(),
                            playerId = rd[3].ToString(),
                            playerName = rd[4].ToString(),
                            playerPosition = rd[5].ToString(),
                            playerImage = rd[6].ToString()
                        });                        
                    }
                    return PlayerList;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Position Not Found");
                }
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }
        }

        public string AddNewPlayer(PlayersController newPlayer)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("insert into Players values(@playerId,@playerName,@playerPosition,@playerTeamId,@playerImage)", con);
            cmd.Parameters.AddWithValue("@playerId", newPlayer.playerId);
            cmd.Parameters.AddWithValue("@playerName", newPlayer.playerName);
            cmd.Parameters.AddWithValue("@playerPosition", newPlayer.playerPosition);
            cmd.Parameters.AddWithValue("@playerTeamId", newPlayer.playerTeamId);
            cmd.Parameters.AddWithValue("@playerImage", newPlayer.playerImage);

            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "Player Added Successfully";
        }

        public string UpdatePlayer(PlayersController update)
        {
            
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("update Players set playerPosition=@playerPosition,playerTeamId=@playerTeamId, playerImage = @playerImage where playerName=@playerName", con);
            cmd.Parameters.AddWithValue("@playerPosition", update.playerPosition);
            cmd.Parameters.AddWithValue("@playerImage", update.playerImage);
            cmd.Parameters.AddWithValue("@playerTeamId", update.playerTeamId);
            cmd.Parameters.AddWithValue("@playerName", update.playerName);
                        
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            if (result == 1)
            {
                return "Player Updated Successfully";
            }
            throw new Exception("Update Failed");
        }

        public string DeletePlayer(string p_playerName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("delete from Players where playerName=@playerName", con);
            cmd.Parameters.AddWithValue("@playerName", p_playerName);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            if (result == 1)
            {
                return "Player Removed Successfully";
            }
            throw new Exception("Player Name Not Found");

        }

        #endregion
    }
}
