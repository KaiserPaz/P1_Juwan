﻿using Microsoft.AspNetCore.Mvc;

namespace FIFAAPI.Controllers
{
    public class TeamController : Controller
    {
        #region Team controls
        TeamsController teamObj = new TeamsController();
        [HttpGet]
        [Route("TeamList")]
        public IActionResult ShowAllTeams()
        {
            return Ok(teamObj.ShowAllTeams());
        }

        [HttpGet]
        [Route("TeamList/{teamName}")]
        public IActionResult GetTeamByName(string teamName)
        {
            try
            {
                return Ok(teamObj.GetTeamByName(teamName));
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("TeamList/add")]
        public IActionResult AddNewTeam(TeamsController newObj)
        {
            return Ok(teamObj.AddNewTeam(newObj));
        }
        #endregion
    }
}
