﻿using Microsoft.AspNetCore.Mvc;

namespace FIFAAPI.Controllers
{
    public class PlayerController : Controller
    {
        #region Player Controls
        PlayersController playerObj = new PlayersController();

        [HttpGet]
        [Route("PlayerList/{playerName}")]
        public IActionResult GetPlayerByName(string playerName)
        {
            try
            {
                return Ok(playerObj.GetPlayerByName(playerName));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("PlayerList/positions/{playerPosition}")]
        public IActionResult GetPlayersByPosition(string playerPosition)
        {
            try
            {
                return Ok(playerObj.GetPlayersByPosition(playerPosition));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("PlayerList/add")]
        public IActionResult AddNewPlayer(PlayersController newObj)
        {
            return Ok(playerObj.AddNewPlayer(newObj));
        }

        [HttpPut]
        [Route("PlayerList/update")]
        public IActionResult UpdatePlayer(PlayersController update)
        {
            return Ok(playerObj.UpdatePlayer(update));
        }

        [HttpDelete]
        [Route("PlayerList/delete/{playerName}")]
        public IActionResult DeletePlayer(string playerName)
        {
            try
            {
                return Ok(playerObj.DeletePlayer(playerName));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }
        }
        #endregion
    }
}
