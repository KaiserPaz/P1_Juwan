﻿using System.Data.SqlClient;
namespace FIFAAPI
{
    public class TeamsController : PlayersController
    {
        #region Properties
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string Country { get; set; }
        public string teamFlag { get; set; }
        public string teamJersey { get; set; }
        #endregion


        #region Team controls
        public List<TeamsController> ShowAllTeams()
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("select * from Teams", con);
            con.Open();
            List<TeamsController> teamsList = new List<TeamsController>();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                teamsList.Add(new TeamsController()
                {
                    teamId = Convert.ToInt32(rd[0]),
                    teamName = rd[1].ToString(),
                    Country = rd[2].ToString(),
                    teamFlag = rd[3].ToString(),
                    teamJersey = rd[4].ToString()
                });
            }
            rd.Close();
            con.Close();
            return teamsList;

        }
        public List<TeamsController> GetTeamByName(string p_teamName)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

            SqlCommand cmd = new SqlCommand("select Teams.TeamId , Teams.TeamName , Teams.Country , Players.playerId, Players.playerName, Players.playerPosition from Teams left join Players on Teams.TeamId = Players.playerTeamId where teamName = @teamName", con);            
            cmd.Parameters.AddWithValue("@teamName", p_teamName);
            con.Open();
            List<TeamsController> TeamList = new List<TeamsController>();            
            SqlDataReader rd = cmd.ExecuteReader();            
            try
            {                
                if (rd.Read())
                {
                    while (rd.Read())
                    {
                        TeamList.Add(new TeamsController()
                        {
                            teamId = Convert.ToInt32(rd[0]),
                            teamName = rd[1].ToString(),
                            Country = rd[2].ToString(),
                            playerId = rd[3].ToString(),
                            playerName = rd[4].ToString(),
                            playerPosition = rd[5].ToString()
                        });
                    }
                    rd.Close();
                    con.Close();
                    return TeamList;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Team Not Found");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }
        }
        public string AddNewTeam(TeamsController newTeam)
        { 
           SqlConnection con = new SqlConnection(@"server=DESKTOP-MALFHJ4\JUWANINSTANCE;database=FIFAAPI;user id=sa;password=Password1234");

           SqlCommand cmd = new SqlCommand("insert into Teams values(@teamId,@teamName, @Country, @teamFlag, @teamJersey)", con);
           cmd.Parameters.AddWithValue("@teamId", newTeam.teamId);
           cmd.Parameters.AddWithValue("@teamName", newTeam.teamName);
           cmd.Parameters.AddWithValue("@Country", newTeam.Country);
           cmd.Parameters.AddWithValue("@teamFlag", newTeam.teamFlag);
           cmd.Parameters.AddWithValue("@teamJersey", newTeam.teamJersey);
           con.Open();
           int result = cmd.ExecuteNonQuery();
           con.Close();
                                  
           return "Team Added Successfully";
            
        }
        #endregion
    }
}
